from flask import Flask, render_template, request, redirect
import pymysql

#connect to database
db = pymysql.connect("localhost", "root", "", "flask")

app = Flask(__name__)



@app.route('/')
def index():
    return render_template("index.html")

@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/media')
def media():
    return render_template("media.html")

@app.route('/product')
def product():
    return render_template("product.html")

@app.route('/product/cd')
def productcd():
    return render_template("cd.html")

@app.route('/product/dvd')
def productdvd():
    return render_template("dvd.html")

@app.route('/product/sticker')
def productsticker():
    return render_template("sticker.html")

@app.route('/product/apparel')
def productapparel():
    return render_template("apparel.html")


@app.route('/wishlist', methods = ['POST', 'GET'])
def wishlist():
    if request.method== 'POST':
        item = request.form["wish"]
        cursor = db.cursor()
        sql = "INSERT INTO wish(`productname`) VALUES (%s)"
        cursor.execute(sql,(item))
        cursor.execute("SELECT * FROM `wish`")
        output = cursor.fetchall()
        db.commit()
        cursor.close()
        return render_template ("wishlist.html", output = output)
    else:
        return render_template("wishlist.html")

@app.route('/submit', methods = ['POST', 'GET'])
def submit():
    if request.method =='POST':
        contact = request.form
        name = contact["name"]
        mail = contact["mail"]
        message = contact["msg"]
        cursor = db.cursor()
        sql = "INSERT INTO contact(`name`, `mail`, `message`) VALUES (%s, %s, %s)"
        cursor.execute(sql,(name, mail, message))
        db.commit()
        cursor.close()
        return redirect("submit")
    else:
        return render_template("submit.html")

@app.route('/contact', methods = ['POST', 'GET'])
def contact():
    return render_template("contact.html")



if __name__ == '__main__':
    app.run(debug = True)
